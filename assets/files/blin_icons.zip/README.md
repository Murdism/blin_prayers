# App icons for Blin Prayers

Three options, all in the wine-and-gold manuscript theme used in the app.
Pick whichever you like best.

## Files

| File | What it is |
|---|---|
| `icon_a_cross.png` | **Option A** — clean gold cross on wine, with the manuscript ring. Most legible at small sizes. |
| `icon_b_cross_geez.png` | **Option B** — cross with the Ge'ez letter ግ (first letter of *ግናቲትድ*) on an illuminated parchment panel below. |
| `icon_c_ornate_cross.png` | **Option C** — pattée-style cross with gold filigree flourishes above and below. The most ornate. |
| `*_foreground.png` | Foreground-only versions (transparent background, larger cross) for Android adaptive icons. |
| `*.svg` | Source files. Edit and re-export if you want to tweak colors or shapes. |

All PNGs are **1024 × 1024** — the size Google Play requires.

## How to use in your Flutter project

The README in the project root already has the icon section, but the short version:

1. Copy the icon you want into `assets/`:
   ```
   cp icon_a_cross.png ../blin_prayers/assets/icon.png
   cp icon_a_foreground.png ../blin_prayers/assets/icon_foreground.png
   ```
2. Add (or update) the `flutter_launcher_icons` block in `pubspec.yaml`:
   ```yaml
   dev_dependencies:
     flutter_launcher_icons: ^0.13.1

   flutter_launcher_icons:
     android: true
     ios: true
     image_path: "assets/icon.png"
     adaptive_icon_background: "#7A1F2B"
     adaptive_icon_foreground: "assets/icon_foreground.png"
   ```
3. Run:
   ```
   flutter pub get
   dart run flutter_launcher_icons
   ```
   This generates every density Android needs (`mipmap-mdpi` through `mipmap-xxxhdpi`) and the iOS icon set automatically.

4. Rebuild: `flutter run` (or `flutter build appbundle` for release).

## For the Play Store listing

You'll also need a **512 × 512** PNG for the store icon. You can resize `icon_a_cross.png` (or whichever you chose) down to 512 in any image tool, or with ImageMagick:
```
convert icon_a_cross.png -resize 512x512 store_icon_512.png
```
